# Tacotron 2(NVIDIA + hccho2)
This is modified versrion of NVIDIA Tacotron2, considering korean preprocess method.
Please see [Blog Post](https://joungheekim.github.io/2021/04/01/code-review/) written in korean for details.

## Reference
- Full Code : [NVIDIA Tacotron2](https://github.com/JoungheeKim/tacotron2)
- Korean Preprocess Code : [hccho2 Tacotron2](https://github.com/hccho2/Tacotron2-Wavenet-Korean-TTS)